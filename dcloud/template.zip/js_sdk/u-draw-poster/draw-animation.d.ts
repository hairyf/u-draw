export default class DrawAnimation {
}
