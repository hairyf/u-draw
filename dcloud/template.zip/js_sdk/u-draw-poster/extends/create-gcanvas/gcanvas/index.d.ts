import { drawPosterExtends } from "../../../utils/interface";

export declare var WeexBridge: any;


export declare var Image: any;

declare function enable(el, options: { bridge, debug, disableAutoSwap, disableComboCommands }): drawPosterExtends['gcanvas']['enable'];