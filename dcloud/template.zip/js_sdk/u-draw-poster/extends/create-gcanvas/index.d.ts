import { DrawPosterUseOpts } from '../../utils/interface';
export * from './gcanvas';
declare const _default: DrawPosterUseOpts;
export default _default;
