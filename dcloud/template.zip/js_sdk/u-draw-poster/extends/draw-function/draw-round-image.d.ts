import { DrawPosterUseCtxOpts } from '../../utils/interface';
declare const _default: DrawPosterUseCtxOpts;
/** 绘制圆角图片原型方法 */
export default _default;
