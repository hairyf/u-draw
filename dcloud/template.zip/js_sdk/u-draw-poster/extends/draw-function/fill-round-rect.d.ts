import { DrawPosterUseCtxOpts } from '../../utils/interface';
declare const _default: DrawPosterUseCtxOpts;
/** 绘制填充圆角矩形方法 */
export default _default;
