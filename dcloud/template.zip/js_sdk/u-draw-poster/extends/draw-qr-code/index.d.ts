declare const _default: {
    name: string;
    handle: any;
    errorCorrectLevel: any;
};
export default _default;
