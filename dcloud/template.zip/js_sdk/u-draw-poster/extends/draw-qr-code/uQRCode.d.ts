declare const uQRCode: any
export default uQRCode