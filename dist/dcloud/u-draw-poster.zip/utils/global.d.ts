/// <reference types="@dcloudio/types" />
declare let gbl: UniApp.Uni;
declare const ENV_UNI: boolean;
declare const ENV_WX: boolean;
export { ENV_UNI, ENV_WX };
export default gbl;
